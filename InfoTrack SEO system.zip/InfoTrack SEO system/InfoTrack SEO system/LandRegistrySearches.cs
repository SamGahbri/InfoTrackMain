using System;

namespace InfoTrack_SEO_system
{
    public class LandRegistrySearches
    {
        
        public string Client { get; set; }
    }
}
