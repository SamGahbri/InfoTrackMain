﻿namespace InfoTrack_SEO_system.Controllers
{
    internal class HttPClient
    {
    }
}