﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace InfoTrack_SEO_system.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LandRegistrySearchesController : ControllerBase
    {
        //public class LandRegistrySearches : System.Net.HttpListenerTimeoutManager
        //{
        static readonly HttpClient client = new HttpClient();

        public static object Client { get; private set; }

        private static async Task Main()
            {
                try
                {
                    HttpResponceMessage responce = await Client.Getasync("https://www.google.co.uk/search?num=100&q=land+registry+search");
                    responce.EnsureSuccessStatusCode();
                    string responceBody = await responce.content.ReadAsStringAsync();

                    Console.WriteLine(responce);
                }
                catch (HttpRequestException)
            {
                    Console.WriteLine();
                    Console.WriteLine();
                }
            }

            private Task<HttpResponceMessage> GetAsync(string v)
            {
                throw new NotImplementedException();
            }
        }

        }
    }


