﻿using System;

namespace InfoTrack_SEO_system.Controllers
{
    internal class HttpResponceMessage
    {
        internal readonly object content;

        internal void EnsureSuccessStatusCode()
        {
            throw new NotImplementedException();
        }
    }
}